import telebot
from telebot import types
import time
import json
import os
import random
import re
import threading
from datetime import datetime

API_TOKEN = '8257633072:AAFtTI0Dn83uaK2CCO8kNKJk8KDcFbrueoQ'
OWNER_ID = 8442352135

bot = telebot.TeleBot(API_TOKEN)
DATA_FILE = 'data.json'
BACKUP_FILE = 'data_backup.json'

# 🔥 FILL YOURSELF
roasts_list = [
"Tera existence hi lagta hai system error se generate hua hai 💀",
"Tujhe dekh ke lagta hai evolution kabhi kabhi give up kar deta hai 🤡",
"Dimag itna halka hai ki hawa me udd jaayega 🗿",
"Tera face dekh ke lagta hai nature ne experiment kiya tha aur fail ho gaya 😂",
"Tujhse argument karna matlab wall se baat karna 🧱",
"Tu insult bhi deserve nahi karta, effort waste hai 😏",
"Tera logic dekh ke calculator bhi hang ho jaye 🤖",
"Tere jaisa backup bhi koi nahi rakhta 💀",
"Tu problem nahi, pura disaster package hai 🤡",
"Tera level itna low hai ki ground bhi sharma jaaye 📉",
"Tu khud ki value khud hi zero kar deta hai 😂",
"Tere dimaag me loading hi chalti rehti hai ⏳",
"Tu serious hai ya nature ka prank hai? 😏",
"Tera attitude free hai kya? Quality bilkul nahi 🤡",
"Tere jaisa banda ignore karna hi best feature hai 🗿",
"Tu jitna bolta hai utna hi irrelevant lagta hai 💀",
"Tera future bhi tera logic jaisa hi dark hai 😂",
"Tu khud ka hi worst version hai 🤡",
"Tujhe samajhna bhi time waste hai 😏",
"Tera brain offline hai permanently 🧠❌",
"Tu jitna bolta hai utna hi khud ko expose karta hai 💀",
"Tere paas confidence zyada hai, reason zero 🤡",
"Tera attitude dekh ke lagta hai content missing hai 😂",
"Tujhe roast karna matlab already burnt cheez ko jalana 🔥",
"Tu itna useless hai ki error bhi tujhe ignore kare 😏",
"Tera level itna neeche hai ki comparison bhi insult ho jaye 🤡",
"Tu khud hi apni beizzati ka source hai 😂",
"Tere jaisa banda mute pe hi acha lagta hai 🔇",
"Tera dimaag aur tera logic dono missing hai 💀",
"Tujhe dekh ke lagta hai expectations galat cheez hai 🤡",
"Tu khud ka example hai 'what not to be' 😏",
"Tera brain shortcut me hi atka hua hai 😂",
"Tujhse better silence hota hai 🤡",
"Tera attitude bada hai, par capacity zero 💀",
"Tujhe seriously lena sabse bada joke hai 😂",
"Tera existence optional lagta hai 🤡",
"Tere jaisa banda update bhi deserve nahi karta 📉",
"Tu offline hi theek tha 😏",
"Tujhe ignore karna hi sabse bada respect hai 😂",
"Tera reply = waste of time 🤡",
"Tu jitna bolta hai utna hi girta hai 💀",
"Tera level itna low hai ki shadow bhi chhod de 🤡",
"Tujhse better bug hota hai 😂",
"Tera dimaag beta version me hi atka hai 😏",
"Tu khud hi apni problem hai 💀",
"Tera existence ek warning hona chahiye 🤡",
"Tujhe dekh ke lagta hai retry option hona chahiye 😂",
"Tera logic aur tera luck dono missing hai 😏",
"Tere jaisa banda mute hi sahi lagta hai 💀",
"Tera level = zero effort 🤡",
"Tu bolta kam, embarrass zyada hota hai 😂",
"Tera brain airplane mode pe hai 🛫",
"Tu jitna try karta utna fail hota hai 💀",
"Tera confidence bina base ka building hai 🏚️",
"Tujhe dekh ke lagta hai glitch ho gaya reality me 🤡",
"Tera logic 404 error hai 😂",
"Tujhe ignore karna hi best reply hai 😏",
"Tera system corrupt hai 💀",
"Tu khud hi apni limitation hai 🤡",
"Tera presence hi negative impact hai 📉",
"Tu jitna loud hai utna hi empty hai 💀",
"Tera dimaag background me bhi run nahi karta 🤡",
"Tujhe dekh ke lagta hai patience waste ho gaya 😂",
"Tera level itna low hai ki effort bhi waste lagta 😏",
"Tera attitude overhyped hai 💀",
"Tera brain buffering me atka hai 🤡",
"Tujhse better random generator hota 😂",
"Tera output hamesha bekaar hota hai 😏",
"Tera logic crash ho chuka hai 💀",
"Tujhe seriously lena mistake hai 🤡",
"Tu jitna bolta hai utna hi irrelevant ho jata hai 💀",
"Tera dimaag standby mode me hai 🤡",
"Tujhe dekh ke lagta hai hope galat cheez hai 😂",
"Tera existence ek bug hai 😏",
"Tujhse better silence hi sahi hai 💀",
"Tera level itna low hai ki compare bhi nahi kar sakte 🤡",
"Tera logic ka koi backup nahi 😂",
"Tera attitude fake confidence hai 😏",
"Tera brain update reject kar deta hai 💀",
"Tujhe samajhna impossible nahi, useless hai 🤡",
"Tu jitna bolta hai utna hi khud ko giraata hai 💀",
"Tera system permanently broken hai 🤡",
"Tujhse better error message hota 😂",
"Tera logic kabhi load hi nahi hota 😏",
"Tera existence unnecessary lagta hai 💀",
"Tujhe ignore karna hi solution hai 🤡",
"Tera level itna low hai ki mention bhi waste 😂",
"Tera brain reboot bhi fail ho jaye 😏",
"Tera attitude hi tera downfall hai 💀",
"Tujhse better blank screen hoti 🤡",
"Tu jitna bolta hai utna hi joke ban jata hai 💀",
"Tera logic khud confuse hai 🤡",
"Tujhe dekh ke lagta hai retry needed 😂",
"Tera dimaag hang ho chuka hai 😏",
"Tera existence optional update jaisa hai 💀",
"Tujhse better silence hi powerful hai 🤡",
"Tera level itna low hai ki effort waste 😂",
"Tera brain response hi nahi deta 😏",
"Tera attitude mismatch hai 💀",
"Tujhe seriously lena impossible hai 🤡",
"Tu jitna bolta hai utna hi useless lagta hai 💀",
"Tera brain inactive hai 🤡",
"Tujhe dekh ke lagta hai system crash ho gaya 😂",
"Tera logic kabhi exist hi nahi karta 😏",
"Tera existence extra load hai 💀",
"Tujhse better nothing hota 🤡",
"Tera level itna low hai ki mention bhi insult hai 😂",
"Tera brain dead zone me hai 😏",
"Tera attitude hi tera biggest bug hai 💀"
]
reply_list = [
"Kya chahiye bhai 😏",
"Bol na, kya scene hai 🤨",
"Aaya tera baap 😎",
"Kyu bula raha hai mujhe 👀",
"Ha bol, jaldi bol 🗿",
"Zyada free ho kya 🤡",
"Main yahi hoon, tension mat le 😂",
"Command de warna chup reh 😏",
"Ab kya dikkat hai tujhe 🤨",
"Bas naam lene se kaam nahi chalega 🤖",
"Bol bhai, kya kaam hai 😎",
"Ab kya ukhadna hai 😏",
"Main busy tha, ab bol 🗿",
"Kya problem hai ab 😂",
"Abe seedha bol na 🤡",
"Yaha hoon, panic mat ho 😏",
"Tu fir aa gaya 😂",
"Kya chahiye iss baar 🤨",
"Main free nahi hoon phir bhi bol 😎",
"Zyada importance mat de khud ko 😏",
"Ab kya bakchodi hai 🤡",
"Kya kaam hai jaldi bol 🗿",
"Tu mujhe hi kyun bulata hai 😂",
"Chal bol, time kam hai 😏",
"Aur kitni baar bulaega 😂",
"Kya issue hai ab 🤨",
"Main hi milta hoon tujhe kya 🤡",
"Zinda hoon bhai, bol 😎",
"Bol warna ignore kar dunga 😏",
"Abe haan bol na 😂",
"Main AI hoon, naukar nahi 🤡",
"Kya chahiye direct bol 😏",
"Ab kya karwana hai 😎",
"Har baar main hi kyu 🤨",
"Bol bhai, sun raha hoon 🗿",
"Zyada natak mat kar 😂",
"Seedha point pe aa 😏",
"Ab kya dikkat hai 😎",
"Kya karu tere liye 🤡",
"Bol jaldi warna gaya 😏",
"Main hi yaad aata hoon tujhe 😂",
"Kya tension hai 🤨",
"Aur koi nahi mila kya 🤡",
"Bol warna mute kar dunga 😏",
"Ab kya chahiye 😎",
"Time waste mat kar 🗿",
"Main sun raha hoon, bol 😂",
"Zyada drama mat kar 😏",
"Kya problem solve karu 🤨",
"Phir aa gaya tu 😂",
"Kya scene hai bhai 😎",
"Ab kya karna hai 🤡",
"Main robot hoon magician nahi 😏",
"Kya chahiye simple bol 🗿",
"Abe bol bhi de 😂",
"Zyada smart mat ban 😏",
"Kya help chahiye 😎",
"Phir se main hi yaad aaya 😂",
"Ab kya ukhadna hai 🤡",
"Seedha bol warna ignore 😏",
"Main available hoon bol 🗿",
"Kya dikkat hai ab 🤨",
"Abe jaldi bol 😂",
"Tu ruk nahi sakta kya 🤡",
"Kya chahiye bhai 😏",
"Ab kya bakwas hai 😂",
"Main hoon na bol 😎",
"Kya command hai 🤨",
"Abe tu fir aa gaya 😂",
"Bol warna gaya 😏",
"Kya dikkat chal rahi 🤡",
"Main sun raha hoon 😎",
"Ab kya scene hai 🤨",
"Seedha bol na 😂",
"Main free nahi hoon fir bhi bol 😏",
"Kya chahiye exact bol 🗿",
"Time kam hai jaldi bol 😂",
"Abe direct bol 🤡",
"Main busy hoon fir bhi sun raha 😏",
"Bol bhai kya hua 😎",
"Kya issue hai 🤨",
"Phir aa gaya tu 😂",
"Main hi mila kya 🤡",
"Kya help chahiye 😏",
"Abe bol bhi de 😂",
"Zyada natak nahi 🤡",
"Kya kaam hai 😎",
"Seedha point pe aa 😏",
"Ab kya dikkat 😂",
"Kya karwana hai 🤨",
"Bol warna ignore 😏",
"Aur kitni baar 😂",
"Kya chahiye 🤡",
"Main sun raha 😎",
"Ab kya scene 🤨",
"Bol bhai 😂",
"Zyada drama mat kar 😏",
"Kya help chahiye 😎",
"Phir se main 😂",
"Ab kya chahiye 🤡",
"Seedha bol 😏",
"Main ready hoon 😎",
"Kya issue 😂",
"Bol jaldi 🤨",
"Time waste mat kar 😏",
"Kya kaam hai 😎",
"Phir aa gaya 😂",
"Main hi mila 🤡",
"Kya chahiye 😏",
"Bol warna gaya 😎",
"Ab kya dikkat 🤨",
"Seedha bol 😂",
"Kya help 🤡",
"Main sun raha 😏",
"Kya scene 😎",
"Bol bhai 🤨",
"Zyada natak nahi 😂",
"Kya kaam 😏",
"Seedha point 😎",
"Ab kya 😂",
"Kya karna 🤡",
"Bol warna ignore 😏",
"Kya chahiye 😎",
"Main ready 😂",
"Kya issue 🤨",
"Bol jaldi 😏",
"Time kam hai 😎",
"Kya kaam 😂",
"Phir tu 🤡",
"Main hi 😂",
"Kya chahiye 😏",
"Bol 😎",
"Kya dikkat 🤨",
"Seedha 😂",
"Kya help 🤡",
"Main sun 😏",
"Kya scene 😎",
"Bol bhai 😂",
"Kya kaam 🤨",
"Seedha bol 😏",
"Main ready 😎",
"Kya issue 😂",
"Bol jaldi 🤡",
"Time waste mat kar 😏",
"Kya chahiye 😎",
"Phir aa gaya 😂",
"Main hi 🤡",
"Kya help 😏",
"Bol warna 😎",
"Kya scene 🤨",
"Seedha bol 😂",
"Kya kaam 🤡",
"Main sun 😏",
"Kya chahiye 😎",
"Bol 😂",
"Kya dikkat 🤨",
"Seedha 🤡",
"Kya help 😏",
"Main 😎",
"Bol bhai 😂",
"Kya kaam 🤨",
"Seedha bol 😏",
"Main ready 😎",
"Kya issue 😂",
"Bol jaldi 🤡",
"Time waste 😏",
"Kya chahiye 😎",
"Phir 😂",
"Main 🤡",
"Kya help 😏",
"Bol 😎",
"Kya scene 🤨",
"Seedha 😂",
"Kya kaam 🤡",
"Main sun 😏",
"Kya chahiye 😎",
"Bol 😂",
"Kya dikkat 🤨",
"Seedha 🤡",
"Kya help 😏",
"Main 😎"
]
abuse_reply_list = [
"Abe zyada bakchodi mat kar, seedha reh 😐",
"Gaali deke apni aukaat khud dikha di tune 💀",
"Dimag hai ya sirf hawa bhari hai andar?",
"Tu jitna bolta hai utna hi cheap lagta hai 🤡",
"Abe chup ho ja warna aur beizzati hogi teri 😏",
"Level dekh apna, phir muh khol 🗿",
"Gaali se kuch prove nahi hota, bas tu girta hai 📉",
"Tu argue nahi kar sakta isliye gaali deta hai 😂",
"Thoda control rakh warna log seriously nahi lenge 💀",
"Abe tu overacting band kar 😂",
"Jitna bol raha utna hi weak lag raha 😏",
"Gaali dena band kar, logic la agar hai to 🧠",
"Tu jitna toxic hai utna hi empty hai andar se 💀",
"Abe dimag use kar, muh nahi 🤡",
"Tu khud ko cool samajh raha hai? Reality check le 😂",
"Gaali deke apni respect zero kar di tune 📉",
"Tu jitna try kar raha utna fail ho raha 😏",
"Abe ruk ja, tu khud hi gir raha hai 💀",
"Gaali nahi aati to chup rehna seekh 🤡",
"Tu bolta kam, embarrass zyada hota hai 😂",
"Abe itna bhi kya frustration hai bhai 🗿",
"Tu khud ko expose kar raha hai bina soche 💀",
"Jitna muh kholta utna hi bekaar lagta 😏",
"Gaali dena = haar maan li tune 🤡",
"Abe apna level check kar pehle 😂",
"Tu fight nahi kar raha, bas noise kar raha 💀",
"Thoda dimaag laga le, free ka nahi hai 🧠",
"Tu jitna bolta utna hi funny lagta 😂",
"Abe ruk ja, aur mat gira apne aap ko 😏",
"Tu khud hi apni insult kar raha indirectly 💀",
"Gaali dene se tu strong nahi banega 🤡",
"Abe zyada hawa mein mat ud 😂",
"Tu jitna loud hai utna hi weak hai 💀",
"Thoda control rakh warna log ignore karenge 😏",
"Tu serious hai ya joke chal raha hai? 😂",
"Abe tu khud ko hi expose kar raha hai 🤡",
"Jitna bolta utna hi cringe lagta 💀",
"Gaali se zyada tera attitude bekaar hai 😏",
"Abe itna bhi kya gussa hai 😂",
"Tu jitna try karta utna fail hota 💀",
"Thoda standard badha apna 🤡",
"Tu khud hi apni beizzati kar raha hai 😂",
"Abe ruk ja warna aur nuksaan tera hi hai 😏",
"Tu jitna bolta utna hi girta ja raha 💀",
"Gaali dena band kar, kuch aur try kar 🤡",
"Abe tu seriously le raha hai isko? 😂",
"Tu jitna react karta utna hi weak lagta 💀",
"Thoda level up kar warna yehi chalta rahega 😏",
"Tu khud hi apni value kam kar raha 🤡",
"Abe bas kar, ab bore ho gaya scene 😂",
"Abe naam lene se kaam nahi hota, bol kya chahiye 😏",
"Zyada bulaega to ignore bhi kar sakta hoon 🤡",
"Main free lag raha hoon kya tujhe 🗿",
"Bol jaldi, patience limited hai 😐",
"Bas naam japne se kuch nahi hoga 😂",
"Abe seedha bol, timepass mat kar 😏",
"Tu mujhe hi target kyu karta rehta hai 🤨",
"Bol warna main bhi chup ho jaunga 😎",
"Zyada importance mat de apne aap ko 🤡",
"Kya chahiye exact bata warna jaa 😏",
"Main servant nahi hoon samjha 😐",
"Abe kaam bol, bakchodi band kar 😂",
"Tu bula raha hai ya test le raha hai 🤨",
"Seedha bol warna seen pe chhod dunga 😏",
"Main robot hoon, bhagwan nahi 🤡",
"Bol jaldi warna interest khatam 😐",
"Zyada ping karega to ignore pakka 😏",
"Abe dimag use kar, naam nahi 😂",
"Tu fir aa gaya, kaam bhi hota hai kya 🤨",
"Bol bhai warna main nikal raha 😎",
"Time waste mat kar, kaam bol 😐",
"Main hi mila tujhe roz roz 🤡",
"Seedha command de warna chup 😏",
"Abe jaldi bol, bore ho raha hoon 😂",
"Tu serious hai ya bas try kar raha 🤨",
"Main AI hoon, toy nahi 😎",
"Zyada natak karega to reply band 😐",
"Bol warna mute list me daal dunga 😏",
"Abe kaam hai to bol warna ja 😂",
"Main free nahi hoon jitna tu samajh raha 🤡",
"Seedha bol warna skip 😏",
"Tu bula ke khud confuse ho jata hai 😂",
"Bol jaldi warna interest zero 😐",
"Main tere liye hi nahi bana hoon 😎",
"Zyada over mat ho, limit me reh 🤡",
"Seedha bol warna ignore mode on 😏",
"Abe kya chahiye tujhe exactly 😂",
"Tu jitna bulata utna irritate karta 🤨",
"Bol bhai warna main bhi gaya 😎",
"Time waste karna band kar 😐",
"Main bot hoon, babysitter nahi 🤡",
"Seedha bol warna block bhi kar sakta 😏",
"Abe jaldi bol, patience khatam 😂",
"Tu mujhe bula ke khud silent ho jata 🤨",
"Bol warna main bhi chup 😎",
"Zyada mat bol, kaam bol 😐",
"Main serious hoon, tu bhi ho ja 🤡",
"Seedha bol warna reply nahi milega 😏",
"Abe last chance bol kya chahiye 😂",
"Ab bol bhi de warna main ignore 😎",
"Tehri shakal dekh kar lagta hai ki kudrat bhi kabhi kabhi mazak karti hai.",
"Bhai, thoda dimaag udhaar le aa, shayad kaam ban jaye.",
"तेरी शक्ल देखकर लगता है कि कुदरत भी कभी-कभी मज़ाक के मूड में होती है।",
"भाई, तू इतना सीधा है कि तुझे जलेबी भी टेढ़ी लगती होगी।",
"तेरी बातें सुनकर ऐसा लगता है जैसे किसी ने खाली डब्बे में कंकड़ डाल दिए हों।",
"अगर बेवकूफी का कोई ओलंपिक होता, तो तू गोल्ड मेडल पक्का लाता।",
"तेरी बुद्धि और मोबाइल का डेटा दोनों ही महीने के अंत में खत्म हो जाते हैं।",
"तू वो दोस्त है जिसे देखकर 'Evolution' थ्योरी पर शक होने लगता है।",
"तेरा दिमाग और 2G नेटवर्क, दोनों ही कभी टाइम पर काम नहीं करते।",
"जितนา तू बोलता है, उतना अगर पढ़ लेता तो आज वैज्ञानिक होता।",
"तेरी पर्सनैलिटी देखकर लगता है कि भगवान ने तुझे 'Draft' में छोड़ दिया था।",
"तू इंसान नहीं, तू धरती पर एक 'Technical Error' hai.",
"भाई, तू इतना हैंडसम है कि आईना भी तुझे देखकर कहता है 'ये क्या देख लिया'।",
"तेरी अक्ल घास चरने गई है और गाय उसे खाकर बीमार पड़ गई।",
"तुझे देखकर लगता है कि अक्ल बंट रही थी और तू लाइफ़ में सबसे पीछे खड़ा था।",
"तेरी बातों में इतना वजन है कि सामने वाले का सिर दर्द करने लगता है।",
"तू वो हीरा है जिसे कचरे के ढेर में भी कोई नहीं ढूंढेगा।",
"तेरी हंसी सुनकर ऐसा लगता है जैसे कोई पुरानी गाड़ी स्टार्ट हो रही हो।",
"जितना तू झूठ बोलता है, उतनी तो नेताओं की रैलियां भी नहीं होतीं।",
"तेरी फोटो देखकर एडिटर्स भी कहते हैं—'भाई, हम भगवान नहीं हैं'।",
"तू इतना 'Famous' hai कि तुझे तेरे घरवाले भी भूल जाते हैं।",
"तेरी संगत में रहकर तो Google bhi search karna bhool jaye.",
"Shakal dekh kar lagta hai ki upar wale ne tumhe galti se 'Draft' me save kar diya tha.",
"Bhai, tere dimaag me gobar hai ya gobar me dimaag? Samajh nahi aata.",
"Tujhe dekh kar toh Darwin bhi ro pada hoga, Evolution ka rasta hi bhatak gaya.",
"Tera chehra dekh kar lagta hai ki kisi ne 5 saal ke bacche ko paintbrush pakda diya tha.",
"Itni bezzati toh teri school me bhi nahi hui wins jitni teri shakal roz karti hai.",
"Tu wahi hai na jise dekh kar log kehte hain 'Dharti bojh hai, par uthana padta hai.'",
"Tera IQ score tere jooton ke number se bhi kam hai.",
"Bhagwan ne tujhe banaya toh tha, par phir manual padhna bhool gaye.",
"Tujhse zyada kaam toh mere purane phone ki battery karti hai.",
"Tu dimaag chalane ki koshish mat kar, engine se dhuaan nikal jayega.",
"Teri baaton se lagta hai ki tu internet pe nahi, sadak pe rehta hai.",
"Bhai, thoda logic use kar liya kar, tax nahi lagta uspe.",
"Tu utna hi zaroori hai jitna YouTube ads me 'Skip' button ka intezaar.",
"Teri personality bilkul uss pop-up ad jaisi hai jise koi dekhna nahi chahta.",
"Lagta hai tere maa-baap ne tujhe paala nahi, sirf jhela hai.",
"Tujhe dekh kar lagta hai ki Error 404: Brain Not Found.",
"Itna sannata kyu hai? Lagta hai tune phir se kuch bol diya.",
"Tu woh insaan hai jise GPS bhi rasta dikhane se mana kar de.",
"Teri shakal par 'Low Battery' likha hona chahiye.",
"Tu bolta hai toh lagta hai jaise kisi ne puraane radio me mirchi daal di ho.",
"Bhai, thoda dimaag udhaar le aa, shayad kuch kaam ban jaye.",
"Teri kismat aur teri shakal dono me ek hi cheez common hai Dono kharab hain.",
"Tere dimaag ki jagah agar Wi-Fi hota toh kam se kam connect toh hota.",
"Tujhe dekh kar lagta hai ki 'Natural Disaster' ka matlab kya hota hai.",
"Tu wahi hai na jo mirror ke samne khada hoke khud se darr jata hai?",
"Itni bakwaas karte ho, internship kar rahe ho kya kisi comedy show me?",
"Teri baatein sunkar mera dimaag 'Uninstall' hone ka option dhund raha hai.",
"Tu utna hi smart hai jitna ek stone-age ka mobile.",
"Tera sense of humor itna purana hai ki use museum me hona chahiye.",
"Bhai, tujhe ignore karna meri hobby banti ja rahi hai.",
"Teri baatein me vajan nahi, sirf kachra hai.",
"Tu insaan nahi, chalta-firta meme hai.",
"Teri shakal dekh kar lagta hai ki god ne 'Undo' button dhunda tha par mila nahi.",
"Tu woh hai jise dekh kar dubaara 'Captcha' bharne ka mann karta hai.",
"Itni negativity? Lagta hai subah-subah karele ka juice pi liya.",
"Tere dimaag me 'Processing Error' hamesha chalta rehta hai.",
"Tu woh hai jo 1 rupaye ki chocolate ke liye 10 rupaye ka auto karke jaye.",
"Teri baatein itni boring hain ki insomnia ka mareez bhi so jaye.",
"Tu dimaag bech kyu nahi deta? Bilkul naya hi toh hai, kabhi use toh kiya nahi.",
"Teri shakal pe itni confusion hai ki Google bhi search karte waqt atak jaye.",
"Bhai, tera network aur dimaag dono hi out of reach rehte hain.",
"Tu utna hi useless hai jitna 'p' in 'psychology'.",
"Teri baatein sunkar lagta hai ki kisi ne mixer-grinder me patthar daal diye hain.",
"Tu dunya ka woh raaz hai jise koi jaan-na hi nahi chahta.",
"Tera attitude teri salary se 10 guna zyada hai, jo ki zero hai.",
"Tu woh hai jo group photo me hamesha 'Crop' kar diya jata hai.",
"Teri life ek movie hai, par kisi ko ticket nahi kharidni uski.",
"Bhai, thoda padh liya kar, sirf keyboard chalane se ghar nahi chalta.",
"Teri shakal dekh kar lagta hai ki 'Ctrl+C' aur 'Ctrl+V' me error aa gaya tha.",
"Tu utna hi boring hai jitna bina masala ka poha.",
"Teri dosti aur dimaag dono hi saste hain.",
"Tujhe dekh kar lagta hai ki biology teacher ne padhate waqt shortcut liya tha.",
"Tu woh galti hai jo tere parents chhupane ki koshish karte hain.",
"Teri baatein sunkar mera dimaag factory reset maang raha hai.",
"Tu insaan kam, cartoon network zyada lagta hai.",
"Teri logic sunke Newton ne apni kabra me karwat badli hogi.",
"Tu wahi hai na jise log 'Galti se mistake' kehte hain?",
"Teri shakal pe barah baj rahe hain, wo bhi AM wale nahi.",
"Tu woh virus hai jise antivirus bhi detect karne se sharma jaye.",
"Bhai, tu bolta hai toh lagta hai jaise kisi ne dhol fatne ki awaaz nikali ho.",
"Tera dimaag toh thik hai na? Check karwa le, expiry date nikal gayi hogi.",
"Tu utna hi 'cool' hai jitna ek garam tawa.",
"Teri baatein sunne se accha hai main alarm clock ki awaaz sunu.",
"Tu dunya ka 8wa ajooba hai—Sabse bada namuna.",
"Teri personality bilkul 'Low Data' mode jaisi hai.",
"Tujhe dekh ke lagta hai ki 'Waste of Space' ka definition kya hai.",
"Tera opinion utna hi maayne rakhta hai jitna chips ke packet me hawa.",
"Tu woh insaan hai jo calculator se bhi galat answer nikal le.",
"Teri shakal pe 'Do Not Enter' ka sign hona chahiye.",
"Bhai, tu rehne de, tujhse sirf bezzati hi ho payegi.",
"Teri life ka ek hi maqsad hai—Logo ka sir dard karna.",
"Tu woh user hai jise dekh kar bot bhi offline chala jaye.",
"Tera dimaag bilkul 2G jaisa slow hai.",
"Teri baatein sunkar lagta hai ki dimaag ki dukan pe sale lagi thi aur tu kuch nahi laya.",
"Tu utna hi special hai jitna ek bina stamp wala lifafa.",
"Teri shakal dekh kar lagta hai ki bhagwan thak gaye the banate-banate.",
"Tu insaan nahi, dunya ka sabse sasta software.",
"Tu itna irritating hai ki log airplane mode on kar lete hain.",
"Tera face dekh ke kismat bhi thak gayi hogi.",
"Tu woh mistake hai jo undo bhi nahi hoti.",
"Tera level itna low hai ki respect bhi reach nahi karti.",
"Tu banda nahi, permanent headache hai.",
"Tujhse baat karna matlab time ko insult karna.",
"Tu itna useless hai ki Google bhi tujhe ignore kare.",
"Tera dimaag kaam nahi karta, bas space occupy karta hai.",
"Tu banda kam aur problem zyada hai.",
"Tujhe dekh ke lagta hai nature ne shortcut le liya.",
"Tu itna cringe hai ki log tujhe dekh ke app uninstall kar de.",
"Tera existence pointless lagta hai.",
"Tu banda nahi error 404 hai.",
"Tera face dekh ke lagta hai reality glitch ho gayi.",
"Tu itna annoying hai ki silence better lagta hai.",
"Tera humor itna dead hai ki jokes bhi mar jaye.",
"Tu banda nahi failed experiment hai.",
"Tera brain permanently offline hai.",
"Tu itna bekaar hai ki log tujhe example bana ke warn karte hain.",
"Tera logic itna weak hai ki calculator bhi confuse ho jaye.",
"Tu banda nahi low quality content hai.",
"Tera face dekh ke camera bhi give up kar de.",
"Tu itna useless hai ki shadow bhi follow na kare.",
"Tera future blank screen jaisa hai.",
"Tu banda nahi glitchy update hai.",
"Tera dimaag empty server hai.",
"Tu itna irritating hai ki notifications band kar diye jaye.",
"Tera level itna down hai ki detect bhi nahi hota.",
"Tu banda nahi background error hai.",
"Tera humor outdated hai.",
"Tu itna slow hai ki buffering bhi tujhe chhod de.",
"Tera face low resolution me hi better lagta hai.",
"Tu banda nahi system crash hai.",
"Tera dimaag reboot ke baad bhi kaam na kare.",
"Tu itna bekaar hai ki recycle bin bhi reject kare.",
"Tera existence bug hai jo fix nahi hua.",
"Tu banda nahi useless feature hai.",
"Tera IQ itna kam hai ki zero superior lagta hai.",
"Tu itna cringe hai ki memes bhi avoid kare.",
"Tera future loading screen pe hi atka hai.",
"Tu banda nahi broken code hai.",
"Tera brain hang hai permanently.",
"Tu itna annoying hai ki mute button best lagta hai.",
"Tera face dekh ke pixels bhi thak jaye.",
"Tu banda nahi failed notification hai.",
"Tera humor garbage hai.",
"Tu itna useless hai ki shortcut bhi kaam na aaye.",
"Tera level itna low hai ki notice bhi nahi hota.",
"Tu banda nahi spam message hai.",
"Tera dimaag empty cache hai.",
"Tu itna irritating hai ki ringtone silent ho jaye.",
"Tera face error screen jaisa hai.",
"Tu banda nahi lagging system hai.",
"Tera future dark mode me stuck hai.",
"Tu itna boring hai ki alarm bhi snooze ho jaye.",
"Tera humor expired hai.",
"Tu banda nahi corrupted data hai.",
"Tera brain blank document hai.",
"Tu itna useless hai ki logic bhi reject kare.",
"Tera level tutorial se neeche hai.",
"Tu banda nahi failed update hai.",
"Tera face render incomplete hai.",
"Tu itna cringe hai ki reality bhi deny kare.",
"Tera humor low effort hai.",
"Tu banda nahi broken link hai.",
"Tera dimaag empty folder hai.",
"Tu itna irritating hai ki ads bhi skip ho jaye.",
"Tera face brightness zero jaisa hai.",
"Tu banda nahi warning sign hai.",
"Tera future invisible hai.",
"Tu itna useless hai ki system ignore kare.",
"Tera humor weak network jaisa hai.",
"Tu banda nahi bug report hai.",
"Tera brain outdated hardware hai.",
"Tu itna annoying hai ki headphones bhi fail ho jaye.",
"Tera face pixel loss jaisa hai.",
"Tu banda nahi failed test hai.",
"Tera level negative hai.",
"Tu itna cringe hai ki cringe bhi tujhe block kare.",
"Tera humor outdated meme hai.",
"Tu banda nahi useless patch hai.",
"Tera dimaag crash ho chuka hai.",
"Tu itna boring hai ki sleep mode auto on ho jaye.",
"Tera face lag karta hai.",
"Tu banda nahi failed download hai.",
"Tera future 0% pe stuck hai.",
"Tu itna irritating hai ki volume zero karna pade.",
"Tera humor broken hai.",
"Tu banda nahi fake signal hai.",
"Tera brain low battery pe hai.",
"Tujhe dekh ke plug nikaal dene ka mann kare.",
"Tu itna useless hai ki charger bhi kaam na kare.",
"Tera face outdated version hai.",
"Tu banda nahi spam folder hai.",
"Tera future deleted file jaisa hai.",
"Tu itna cringe hai ki memes block kar de.",
"Tera humor trash hai.",
"Tu banda nahi useless file hai.",
"Tera level zero se neeche hai.",
"Tu itna irritating hai ki silence hi best hai.",
"Tera brain empty hai.",
"Tu banda nahi glitch hai.",
"Tera face error hai.",
"Tu banda nahi system bug hai.",
"Tera future blank hai.",
"Tu itna annoying hai ki ignore best option hai.",
"Tu banda nahi failed expectation hai.",
"Tera existence hi downgrade hai.",
"Tu itna useless hai ki impact zero hai.",
"Tera humor itna flat hai ki reaction bhi nahi aata.",
"Tu banda nahi disappointment ka loop hai.",
"Tujhe dekh ke lagta hai expectations low rakhni chahiye.",
"Tu itna annoying hai ki ignore permanent solution hai.",
"Tera dimaag itna weak hai ki thoughts bhi confuse ho jate hain.",
"Tu banda nahi bad choice hai.",
"Tera future itna empty hai ki plan bhi nahi banta.",
"Tu itna cringe hai ki log skip kar dete hain.",
"Tera humor outdated hai.",
"Tu banda nahi failed concept hai.",
"Tujhe dekh ke lagta hai retry option missing tha.",
"Tu itna useless hai ki presence matter nahi karti.",
"Tera dimaag itna slow hai ki logic late aata hai.",
"Tu banda nahi waste of effort hai.",
"Tera level itna low hai ki compare bhi nahi kar sakte.",
"Tu itna irritating hai ki log naturally avoid karte hain.",
"Tera humor itna weak hai ki laugh nahi aata.",
"Tu banda nahi broken expectation hai.",
"Tujhe dekh ke lagta hai cancel best option hai.",
"Tu itna boring hai ki time slow ho jata hai.",
"Tera dimaag blank hai.",
"Tu banda nahi failed plan hai.",
"Tera future dark hai.",
"Tu itna cringe hai ki ignore kar diya jata hai.",
"Tera humor bekaar hai.",
"Tu banda nahi disappointment ka final version hai."
]

# ---------- STORAGE ----------
def load_data():
    files_to_try = [DATA_FILE, BACKUP_FILE]

    for file in files_to_try:
        try:
            if os.path.exists(file):
                with open(file, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)

                    # Missing keys auto-fix
                    loaded.setdefault("approved_groups", [])
                    loaded.setdefault("approved_users", [])
                    loaded.setdefault("warns", {})

                    print(f"✅ Data loaded from: {file}")
                    return loaded
        except Exception as e:
            print(f"⚠️ Failed loading {file}: {e}")

    return {
        "approved_groups": [],
        "approved_users": [],
        "warns": {}
    }

def save_data():
    try:
        temp_file = DATA_FILE + ".tmp"

        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)

        # Atomic replace (safe save)
        os.replace(temp_file, DATA_FILE)

        # Backup copy
        with open(BACKUP_FILE, 'w', encoding='utf-8') as backup:
            json.dump(data, backup, indent=4)

        print(f"💾 Data Saved Successfully at {datetime.now()}")

    except Exception as e:
        print(f"❌ Save error: {e}")

data = load_data()
approved_groups = set(data.get("approved_groups", []))
approved_users = set(data.get("approved_users", []))  # Approved Users target list
warns = data.get("warns", {})

def save_all():
    data["approved_groups"] = list(approved_groups)
    data["approved_users"] = list(approved_users)
    data["warns"] = warns
    save_data()


# ---------- AUTO SAVE SYSTEM ----------
def auto_backup():
    while True:
        try:
            save_all()
        except Exception as e:
            print(f"⚠️ Auto-backup error: {e}")

        # Every 60 seconds auto save
        time.sleep(60)

backup_thread = threading.Thread(target=auto_backup, daemon=True)
backup_thread.start()

# ---------- INLINE DEV BUTTON ----------
def dev_button():
    markup = types.InlineKeyboardMarkup()
    btn = types.InlineKeyboardButton("𝐒𝐍 𝐗 𝐃𝐀𝐃", url="https://t.me/snxdad")
    markup.add(btn)
    return markup

# ---------- ACCESS CONTROL CHECK ----------
def has_access(user_id):
    # Owner ya fir Approved users list me ho unhe hi access milega
    if user_id == OWNER_ID or user_id in approved_users:
        return True
    return False

# Isko purane get_target_user ki jagah paste karein
def get_target_user(m, text):
    # 1. Reply Check (Sabse pehle check karega)
    if m.reply_to_message:
        return m.reply_to_message.from_user

    # 2. Chat ID Check (Agar text me koi numeric ID likhi ho)
    for arg in text.split():
        if arg.isdigit():
            try:
                return bot.get_chat_member(m.chat.id, int(arg)).user
            except:
                pass

    # 3. Username Check (Agar text me @username likha ho)
    for arg in text.split():
        if arg.startswith("@"):
            username = arg.replace("@", "").lower()
            try:
                members = bot.get_chat_administrators(m.chat.id)
                for member in members:
                    if member.user.username and member.user.username.lower() == username:
                        return member.user
            except:
                pass

    return None

# Purane approvesn block ko hata kar ye teeno commands waha paste karein
@bot.message_handler(commands=['approvesn'])
def approve(m):
    if m.from_user.id != OWNER_ID:
        return
    approved_groups.add(m.chat.id)
    save_all()
    bot.reply_to(m, "✅ Bot Approved in this Group!")

@bot.message_handler(commands=['disapprovesn'])
def disapprove(m):
    if m.from_user.id != OWNER_ID:
        return
    if m.chat.id in approved_groups:
        approved_groups.remove(m.chat.id)
        save_all()
        bot.reply_to(m, "❌ Bot Disapproved From This Group !")
    else:
        bot.reply_to(m, "⚠️ Group Not Approved Contact @sxdad.")

@bot.message_handler(commands=['disapprovesnall'])
def disapprove_all(m):
    if m.from_user.id != OWNER_ID:
        return
    global approved_groups
    approved_groups.clear()
    save_all()
    bot.reply_to(m, "🗑️ Bot Disapproved From All Group !")

@bot.message_handler(commands=['approvesnbot'])
def approve_user(m):
    if m.from_user.id != OWNER_ID:
        return
    
    text_args = m.text.split()
    if len(text_args) < 2:
        return bot.reply_to(m, "⏳ Use: /approvesnbot {user_id}")
    
    target_id = text_args[1]
    if target_id.isdigit():
        uid = int(target_id)
        approved_users.add(uid)
        save_all()
        bot.reply_to(m, f"✅ User {uid} Has Been Given Owner Level Access 👑.")
    else:
        bot.reply_to(m, "❌ Invalid User ID.")


@bot.message_handler(commands=['disapprovesnbot'])
def disapprove_user(m):
    if m.from_user.id != OWNER_ID:
        return

    text_args = m.text.split()
    if len(text_args) < 2:
        return bot.reply_to(m, "⏳ Use: /disapprovesnbot {user_id}")

    target_id = text_args[1]
    if target_id.isdigit():
        uid = int(target_id)

        if uid in approved_users:
            approved_users.remove(uid)
            save_all()
            bot.reply_to(m, f"❌ User {uid} Owner Level Access Removed.")
        else:
            bot.reply_to(m, "⚠️ User Already Not In Owner Access List.")
    else:
        bot.reply_to(m, "❌ Invalid User ID.")


@bot.message_handler(commands=['disapprovesnbotall'])
def disapprove_all_users(m):
    if m.from_user.id != OWNER_ID:
        return

    approved_users.clear()
    save_all()
    bot.reply_to(m, "🗑️ All Owner Level Access Users Removed.")


@bot.message_handler(commands=['listapprovesnbot'])
def list_approved_users(m):
    if m.from_user.id != OWNER_ID:
        return

    if not approved_users:
        return bot.reply_to(m, "⚠️ No Owner Level Access Users Found.")

    msg = "👑 Approved Owner Level Users:\n\n"
    for uid in approved_users:
        try:
            user = bot.get_chat(uid)
            name = user.first_name or "Unknown"
            username = f"@{user.username}" if user.username else "No Username"
            msg += f"• {name} | {username} | <code>{uid}</code>\n"
        except:
            msg += f"• Unknown User | <code>{uid}</code>\n"

    bot.reply_to(m, msg, parse_mode="HTML")


@bot.message_handler(commands=['listapprovesn'])
def list_approved_groups(m):
    if m.from_user.id != OWNER_ID:
        return

    if not approved_groups:
        return bot.reply_to(m, "⚠️ No Approved Groups Found.")

    msg = "📋 Approved Groups List:\n\n"

    for gid in approved_groups:
        try:
            chat = bot.get_chat(gid)
            title = chat.title if chat.title else "Unknown Group"
            msg += f"• {title} | <code>{gid}</code>\n"
        except:
            msg += f"• Unknown Group | <code>{gid}</code>\n"

    bot.reply_to(m, msg, parse_mode="HTML")



# ---------- HELPERS ----------
def is_admin(chat_id, user_id):
    try:
        member = bot.get_chat_member(chat_id, user_id)
        return member.status in ["administrator", "creator"]
    except Exception as e:
        print(f"Admin check error: {e}")
        return False

def is_target_admin(chat_id, user_id):
    return is_admin(chat_id, user_id)

def parse_time(text):
    match = re.search(r'(\d+)([dhms])', text.lower())
    if not match:
        return None

    value = int(match.group(1))
    unit = match.group(2)

    multipliers = {
        'd': 86400,
        'h': 3600,
        'm': 60,
        's': 1
    }

    return value * multipliers.get(unit, 0)

# ---------- PURGE STORAGE ----------
full_purge_running = {}
full_purge_verify = {}

# ---------- MAIN ----------
@bot.message_handler(func=lambda m: True)
def main(m):

    if m.chat.id not in approved_groups:
        return

    text = m.text.lower().strip() if m.text else ""
    user = get_target_user(m, text)

    # 📜 ALL COMMANDS LIST COMMAND (Admin Only Restricted 🔒)
    if text == "cmd":
        # Check karega ki user Admin hai ya khud Owner
        if not is_admin(m.chat.id, m.from_user.id) and m.from_user.id != OWNER_ID:
            return bot.reply_to(m, "❌ Yeh command sirf Group Admins hi use kar sakte hain!")

        commands_msg = (
            "<b>📋 Bot Command List & Info:</b>\n\n"
            "<b>🎭 Public Commands (Sabhi ke liye):</b>\n"
            "• <code>manager</code> - Bot random fun reply dega.\n"
            "• <code>roast kr / gaali de</code> - Reply target user ko Rose style me roast karega.\n"
            "• <code>tumhara baap / papa</code> - Creator ka name dikhayega.\n"
            "• <code>cmd</code> - Yeh commands help list open karega.\n\n"
            "<b>🔒 Admin / Owner Commands (Sirf Approved Users):</b>\n"
            "• <code>chup kr {time}</code> - User ko temporay ya permanent mute karega.\n"
            "• <code>bolne de</code> - User ko unmute karega.\n"
            "• <code>ise fek de</code> - User ko kick karega (Rose style).\n"
            "• <code>ise ban kr</code> - User ko group se ban karega.\n"
            "• <code>maaf kr</code> - User ko unban karega.\n"
            "• <code>admin kr</code> - User ko group admin banayega.\n"
            "• <code>power lele</code> - Admin se saari powers wapas lega.\n"
            "• <code>warn kr</code> - User ko 1 warning dega (3/3 par rules apply).\n"
            "• <code>chhod de</code> - User ki 1 warning kam karega.\n"
            "• <code>jaane de</code> - Group ki saari warnings reset karega.\n"
            "• <code>list</code> - Warned users ki list show karega.\n"
            "• <code>del kr</code> - Reply message ko delete karega.\n"
            "• <code>saaf kr</code> - Target messages ko purge karega.\n"
            "• <code>sab saaf kr</code> - Pura chat saaf karne ke liye verification dega.\n"
            "• <code>pin kr / pin hta</code> - Message ko pin ya unpin karega.\n"
            "• <code>lock kr</code> - Group completely lock (Chat off).\n"
            "• <code>open kr</code> - Group unlock (Text aur screenshots open).\n"
            "• <code>info de</code> - User ki complete ID/Name info nikalega."
        )
        return bot.reply_to(m, commands_msg, parse_mode="HTML")

    # ========================================================
    # 🌟 PUBLIC SECTION: ALL MEMBERS CAN USE THESE
    # ========================================================
    
    # 🤖 PUBLIC BOT REPLY (sn bolne par)
    BOT_NAME = "manager"
    if BOT_NAME in text:
        return bot.send_message(
            m.chat.id,
            random.choice(reply_list) if reply_list else "👀",
            reply_to_message_id=m.message_id,
            reply_markup=dev_button()
        )

    # 👑 BAAP REPLY
    if "tumhara baap" in text or "tumhara papa" in text:
        return bot.send_message(m.chat.id, "𝐒𝐍 𝐗 𝐃𝐀𝐃", reply_markup=dev_button())

    # 🤬 AUTO ABUSE REPLY
    abuse_words = ["mc", "bc", "bsdk", "mkc", "bkl", "bkchodi", "wtf", "chod", "mutthi", "muthi", "gaand", "lode", "chut", "madarchod", "behnchod", "gandu", "chutiya"]

    if any(word in text for word in abuse_words):
        if abuse_reply_list:
            return bot.send_message(
                m.chat.id,
                random.choice(abuse_reply_list),
                reply_to_message_id=m.message_id
            )

        # 🎭 ROAST SYSTEM (Rose Style Mentions Added ✅)
    if "roast kr" in text or "gaali de" in text:
        if not roasts_list:
            return bot.reply_to(m, "⚠️ Roast List Empty Hai")

        if m.reply_to_message:
            target = m.reply_to_message.from_user

            if target.id == OWNER_ID:
                return bot.reply_to(m, "Malik Ko Roast Waah ! Tere Bas Ki baat Nahi Hai Lwde 💀")

            roasts = random.sample(roasts_list, min(3, len(roasts_list)))
            
            # Rose style HTML text format tag create kiya gaya hai
            mention = f'<a href="tg://user?id={target.id}">{target.first_name}</a>'

            for r in roasts:
                bot.send_message(
                    m.chat.id,
                    f"{mention} 💀\n{r}",
                    parse_mode="HTML"
                )
        else:
            roasts = random.sample(roasts_list, min(3, len(roasts_list)))
            for r in roasts:
                bot.send_message(m.chat.id, r)
        return

    # ========================================================
    # 🔒 RESTRICTED SECTION: ONLY OWNER & APPROVED USERS
    # ========================================================
    if not has_access(m.from_user.id):
        return

    # ---------- MUTE SYSTEM (PERMANENT + TIMED) ----------
    if "chup kr" in text:
        if not user or user.id == m.from_user.id:
            return bot.reply_to(m, "❌ User ID Ya Reply Zaroori Hai !")
        if is_admin(m.chat.id, user.id):
            return bot.reply_to(m, "❌ Bhai Ye Admin Hai")
        
        duration = parse_time(text)
        
        if duration:
            # Agar text me time diya ho (e.g., 2d, 5h, 10m, 30s)
            until_timestamp = int(time.time() + duration)
            bot.restrict_chat_member(m.chat.id, user.id, until_date=until_timestamp)
            
            # Message formatting ke liye duration find out karna
            match = re.search(r'(\d+)([dhms])', text)
            time_str = f"{match.group(1)}{match.group(2).upper()}"
            bot.reply_to(m, f"🤐 Muted For {time_str}!")
        else:
            # Agar koi time na ho, to Permanent Mute (Telegram rule: more than 366 days or 0 means permanent)
            # Safe side ke liye hum standard restrict call direct zero settings ya far future date se permanent karte hain.
            bot.restrict_chat_member(
                m.chat.id, 
                user.id, 
                permissions=types.ChatPermissions(can_send_messages=False)
            )
            bot.reply_to(m, "🤐 Permanently Muted!")

    elif "bolne de" in text:
        if not user:
            return bot.reply_to(m, "❌ User not found")
        bot.restrict_chat_member(
            m.chat.id,
            user.id,
            permissions=types.ChatPermissions(
                can_send_messages=True,
                can_send_other_messages=True,
                can_add_web_page_previews=True,
                can_send_polls=True
            )
        )
        bot.reply_to(m, "🗣️ Unmuted")

    # ---------- KICK (ROSE STYLE) ----------
    elif "ise fek de" in text:
        if not user:
            return bot.reply_to(m, "❌ User not found")

        if user.id == OWNER_ID:
            return bot.reply_to(m, "🙄 Bhai Owner Ko Kaise Fek Du?")

        if is_target_admin(m.chat.id, user.id):
            return bot.reply_to(m, "❌ Bhai Ye Admin Hai !")

        try:
            # Rose Bot style kick (ban + instant unban)
            bot.ban_chat_member(m.chat.id, user.id)
            time.sleep(1)
            bot.unban_chat_member(m.chat.id, user.id, only_if_banned=True)

            bot.reply_to(m, f"👢 User Kicked Successfully: {user.first_name}")

        except Exception as e:
            bot.reply_to(m, f"❌ Error: {e}")

    # ---------- BAN ----------
    elif "ise ban kr" in text:
        if not user:
            return bot.reply_to(m, "❌ User not found")
        if is_target_admin(m.chat.id, user.id):
            return bot.reply_to(m, "❌ Bhai ye admin hai, ise ban nahi kar sakta!")
        bot.ban_chat_member(m.chat.id, user.id)
        bot.reply_to(m, "🚫 Banned")

    # ---------- UNBAN ----------
    elif "maaf kr" in text:
        if not user:
            return bot.reply_to(m, "❌ User not found")
        bot.unban_chat_member(m.chat.id, user.id)
        bot.reply_to(m, "😇 Unbanned")

    # ---------- PROMOTE ----------
    elif "admin kr" in text:
        if not user:
            return bot.reply_to(m, "❌ User not found")
        bot.promote_chat_member(
            m.chat.id,
            user.id,
            can_change_info=False,
            can_delete_messages=True,
            can_invite_users=True,
            can_pin_messages=True,
            can_restrict_members=False,
            can_promote_members=False,
            can_manage_chat=True,
            can_manage_video_chats=True
        )
        bot.reply_to(m, "👑 Promoted")

    # ---------- DEMOTE ----------
    elif "power lele" in text:
        if not user:
            return bot.reply_to(m, "❌ User not found")
        bot.promote_chat_member(
            m.chat.id,
            user.id,
            can_change_info=False,
            can_delete_messages=False,
            can_invite_users=False,
            can_pin_messages=False,
            can_restrict_members=False,
            can_promote_members=False,
            can_manage_chat=False,
            can_manage_video_chats=False
        )
        bot.reply_to(m, "📉 Demoted")

    # ---------- WARN ----------
    elif "warn kr" in text:
        if not user:
            return bot.reply_to(m, "❌ User not found")
        if is_target_admin(m.chat.id, user.id):
            return bot.reply_to(m, "❌ Bhai ye admin hai, ise warn nahi kar sakta!")
        cid = str(m.chat.id)
        warns.setdefault(cid, {})
        uid = str(user.id)
        warns[cid][uid] = warns[cid].get(uid, 0) + 1
        save_all()
        bot.reply_to(m, f"⚠️ Warn: {warns[cid][uid]}/3")

    elif "chhod de" in text:
        if not user:
            return bot.reply_to(m, "❌ User not found")
        cid = str(m.chat.id)
        uid = str(user.id)
        warns.setdefault(cid, {})
        warns[cid][uid] = max(0, warns[cid].get(uid, 0) - 1)
        save_all()
        bot.reply_to(m, "➖ Warn removed")

    elif "jaane de" in text:
        warns[str(m.chat.id)] = {}
        save_all()
        bot.reply_to(m, "♻️ All warns reset")

    elif text == "list":
        cid = str(m.chat.id)
        if cid not in warns or not warns[cid]:
            bot.reply_to(m, "No warns")
        else:
            msg = "\n".join([f"{u} : {c}" for u, c in warns[cid].items()])
            bot.reply_to(m, msg)

    # ---------- DELETE ----------
    elif "del kr" in text:
        try:
            if m.reply_to_message:
                bot.delete_message(m.chat.id, m.reply_to_message.message_id)
            bot.delete_message(m.chat.id, m.message_id)
        except:
            pass

        # ---------- PURGE ----------

    elif text == "saaf kr":
        deleted = 0
        # Rose Style Reply Purge (Deletes everything between reply and command)
        if m.reply_to_message:
            start_id = m.reply_to_message.message_id
            end_id = m.message_id
            # Range includes both start and end
            for msg_id in range(start_id, end_id + 1):
                try:
                    bot.delete_message(m.chat.id, msg_id)
                    deleted += 1
                except Exception:
                    continue
            
            # Send status and delete it after 5 seconds to keep chat clean
            status = bot.send_message(m.chat.id, f"✅ Purge Complete\n🗑 Deleted: {deleted} messages")
            time.sleep(5)
            try:
                bot.delete_message(m.chat.id, status.message_id)
            except:
                pass
        
        # Normal Last 100 Purge (Reduced from 400 for better reliability/speed)
        else:
            current_id = m.message_id
            for i in range(101):
                try:
                    bot.delete_message(m.chat.id, current_id - i)
                    deleted += 1
                except Exception:
                    continue
            
            status = bot.send_message(m.chat.id, f"✅ Purge Complete\n🗑 Deleted: {deleted} messages")
            time.sleep(5)
            try:
                bot.delete_message(m.chat.id, status.message_id)
            except:
                pass

    elif text == "sab saaf kr":
        captcha = str(random.randint(1000, 9999))
        full_purge_verify[m.chat.id] = captcha
        bot.reply_to(m, f"⚠️ FULL GROUP PURGE\n\nVerification Code: {captcha}\n\nType:\nconfirm {captcha}")

    elif text.startswith("confirm "):
        code = text.replace("confirm ", "").strip()
        if full_purge_verify.get(m.chat.id) != code:
            return bot.reply_to(m, "❌ Wrong Verification Code")
        full_purge_verify.pop(m.chat.id, None)
        full_purge_running[m.chat.id] = True
        bot.reply_to(m, "🚨 Full Purge Started...\n\nStop: ruk ja")

        def purge_all(chat_id, start_msg):
            current = start_msg
            while full_purge_running.get(chat_id, False):
                try:
                    bot.delete_message(chat_id, current)
                except:
                    pass
                current -= 1
                if current <= 1:
                    break
                time.sleep(0.05)
            full_purge_running[chat_id] = False
            try:
                bot.send_message(chat_id, "✅ Full Purge Finished")
            except:
                pass

        threading.Thread(target=purge_all, args=(m.chat.id, m.message_id), daemon=True).start()

    elif text == "ruk ja":
        if full_purge_running.get(m.chat.id):
            full_purge_running[m.chat.id] = False
            bot.reply_to(m, "🛑 Purge Stopped")

    # ---------- PIN ----------
    elif "pin kr" in text:
        if m.reply_to_message:
            bot.pin_chat_message(m.chat.id, m.reply_to_message.message_id, disable_notification=True)

    elif "pin hta" in text:
        if m.reply_to_message:
            bot.unpin_chat_message(m.chat.id, m.reply_to_message.message_id)

    # ---------- LOCK SYSTEM (MUKAMMAL LOCK) ----------
    elif "lock kr" in text:
        bot.set_chat_permissions(
            m.chat.id,
            types.ChatPermissions(
                can_send_messages=False,
                can_send_audios=False,
                can_send_documents=False,
                can_send_photos=False,
                can_send_videos=False,
                can_send_video_notes=False,
                can_send_voice_notes=False,
                can_send_polls=False,
                can_send_other_messages=False,
                can_add_web_page_previews=False
            )
        )
        bot.reply_to(m, "🔒 Group completely locked.")

    # ---------- UNLOCK SYSTEM (SCREENSHOT LOGIC) ----------
    elif "open kr" in text:
        bot.set_chat_permissions(
            m.chat.id,
            types.ChatPermissions(
                can_send_messages=True,          # Send Text Messages: ON
                can_send_photos=True,            # Photos: ON ✅
                can_send_other_messages=True,    # Stickers & GIFs: ON ✅
                can_add_web_page_previews=True,  # Send Reactions ke liye background permission
                
                # Baki sab as per screenshot OFF rahega:
                can_send_videos=False,           # Videos: OFF ❌
                can_send_audios=False,           # Music: OFF ❌
                can_send_documents=False,        # Files: OFF ❌
                can_send_voice_notes=False,      # Voice Messages: OFF ❌
                can_send_video_notes=False,      # Video Messages: OFF ❌
                can_send_polls=False             # Polls: OFF ❌
            )
        )
        bot.reply_to(m, "🔓 Group unlocked.")

    # ---------- ROSE BOT STYLE IMPROVED INFO ----------
    elif "info de" in text:
        # get_target_user automatically manages reply/username/self
        name = f"{user.first_name or ''} {user.last_name or ''}".strip()
        uid = user.id
        username = f"@{user.username}" if user.username else "None"
        
        # User dynamic/permanent chat link formatting
        link = f"tg://openmessage?user_id={uid}"
        
        info_msg = (
            f"<b>👤 User Information:</b>\n\n"
            f"<b>🔹 Full Name:</b> {name}\n"
            f"<b>🆔 Chat ID:</b> <code>{uid}</code>\n"
            f"<b>📧 Username:</b> {username}\n"
            f"<b>🔗 User Link:</b> <a href='{link}'>Permanent Link</a>"
        )
        bot.reply_to(m, info_msg, parse_mode="HTML")

print("🤖 Bot Started Successfully...")
bot.infinity_polling(skip_pending=True, timeout=60)