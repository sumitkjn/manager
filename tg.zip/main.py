import telebot
from telebot import types
import re
import pymongo
import time
import os
import threading
import dns.resolver

print("🚀 Starting Premium Emoji Wrapper (main.py)...")

# --- 1. PYDROID 3 FIX (DNS ERROR) ---
dns.resolver.default_resolver = dns.resolver.Resolver(configure=False)
dns.resolver.default_resolver.nameservers = ['8.8.8.8']

# --- 2. CONFIGURATION ---
OWNER_IDS = {5535235573, 8278814873, 8442352135}
MONGO_URL = "mongodb+srv://premiumemojis:premiumemojis@cluster0.qpnt8bf.mongodb.net/?appName=Cluster0"

# --- 3. MONGODB CONNECTION ---
print("🔄 Connecting to MongoDB...")
try:
    client = pymongo.MongoClient(MONGO_URL)
    db = client['TelegramBotDB']
    col_emojis = db['emojis']
    col_btn_icons = db['button_icons']   
    col_btn_colors = db['button_colors'] 
    print("✅ Connected to MongoDB Successfully!")
except Exception as e:
    print(f"❌ MongoDB Error: {e}")
    col_emojis = col_btn_icons = col_btn_colors = None

# --- LOCAL CACHE FOR SPEED ---
PREMIUM_MAPPING = {
    "⏳": "5451732530048802485", "🧑‍💻": "6174508000489768736",
    "🚀": "5188481279963715781", "✅": "5427009714745517609",
    "❌": "6282852025159913806", "⚠️": "5447644880824181073",
    "🎉": "5436040291507247633", "🌸": "5440354006335495210",
    "🔥": "5420315771991497307", "😎": "5373141891321699086",
    "📞": "5467539229468793355", "✨": "5472164874886846699",
    "❤️": "5449505950283078474", "📖": "5226512880362332956",
    "🔍": "5188217332748527444", "ℹ️": "5334544901428229844",
    "👑": "5467406098367521267", "⚡️": "5431449001532594346",
    "🏓": "5269563867305879894", "🆔": "5431874671446350745",
    "🚫": "5240241223632954241", "📊": "5431577498364158238",
    "👤": "5373012449597335010", "👥": "5372926953978341366",
    "📢": "5987709143958427072", "🕓": "5846127793313681804",
    "🔧": "5413398757226076065", "🛡": "5285087932107989972",
    "📜": "6323096332579899122", "⛔️": "5260293700088511294",
    "📭": "5352896944496728039", "🗑": "5445267414562389170",
    "📂": "5253526631221307799", "📋": "5197269100878907942"
}

BUTTON_ICONS = {}
BUTTON_COLORS = {}

# MongoDB Se Data Load Karna
if db is not None:
    try:
        for e in col_emojis.find(): PREMIUM_MAPPING[e['_id']] = e.get('emoji_id', '')
        if col_btn_icons is not None:
            for b in col_btn_icons.find(): BUTTON_ICONS[b['_id']] = b.get('icon_id', '')
        if col_btn_colors is not None:
            for c in col_btn_colors.find(): BUTTON_COLORS[c['_id']] = c.get('color', '')
        print("✅ Custom Emojis & Button Settings Loaded!")
    except: pass


# --- 4. CORE CONVERSION LOGIC ---
def auto_premium_text(text):
    if not text or not isinstance(text, str): return text
    if "<tg-emoji" in text: return text 
    
    text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
    text = re.sub(r'\*(.*?)\*', r'<b>\1</b>', text)
    text = re.sub(r'`(.*?)`', r'<code>\1</code>', text)
    
    for emoji_char, premium_id in PREMIUM_MAPPING.items():
        if emoji_char in text:
            text = text.replace(emoji_char, f'<tg-emoji emoji-id="{premium_id}">{emoji_char}</tg-emoji>')
    return text

def clean_and_format_markup(markup):
    if not markup or not hasattr(markup, 'keyboard'): return markup
    
    if isinstance(markup, types.InlineKeyboardMarkup):
        for row in markup.keyboard:
            for button in row:
                b_text_original = button.text
                b_text_lower = b_text_original.lower()
                
                custom_icon_applied = False
                for btn_name, p_id in BUTTON_ICONS.items():
                    if btn_name in b_text_lower:
                        button.icon_custom_emoji_id = p_id
                        custom_icon_applied = True
                        break 
                        
                for btn_name, color in BUTTON_COLORS.items():
                    if btn_name in b_text_lower:
                        button.style = color
                        break
                        
                emoji_pattern = re.compile(r'[\U0001F300-\U0001F6FF\U0001F900-\U0001FAFF\u2600-\u26FF\u2700-\u27BF\u2B50-\u2BFF\U0001F1E6-\U0001F1FF\u2300-\u23FF\u2934-\u2B55]+', flags=re.UNICODE)
                cleaned_text = emoji_pattern.sub('', b_text_original)
                cleaned_text = re.sub(r'[\uFE0F\u200D\U0001F3FB-\U0001F3FF]', '', cleaned_text)
                
                button.text = cleaned_text.strip() 
                        
                if not custom_icon_applied:
                    for emoji_char, premium_id in PREMIUM_MAPPING.items():
                        if emoji_char in b_text_original: 
                            button.icon_custom_emoji_id = premium_id
                            break

    return markup

def wrap_kwargs(kwargs, text_keys=['text', 'caption']):
    for key in text_keys:
        if key in kwargs and kwargs[key]:
            kwargs[key] = auto_premium_text(kwargs[key])
    kwargs['parse_mode'] = 'HTML'
    return kwargs


# --- 5. THE ULTIMATE MONKEY PATCHING (HOOKS) ---

old_send_message = telebot.TeleBot.send_message
def new_send_message(self, chat_id, text, *args, **kwargs):
    kwargs['text'] = text
    kwargs = wrap_kwargs(kwargs)
    if 'reply_markup' in kwargs and kwargs['reply_markup']:
        kwargs['reply_markup'] = clean_and_format_markup(kwargs['reply_markup'])
    return old_send_message(self, chat_id, kwargs.pop('text'), *args, **kwargs)
telebot.TeleBot.send_message = new_send_message

old_reply_to = telebot.TeleBot.reply_to
def new_reply_to(self, message, text, *args, **kwargs):
    kwargs['text'] = text
    kwargs = wrap_kwargs(kwargs)
    if 'reply_markup' in kwargs and kwargs['reply_markup']:
        kwargs['reply_markup'] = clean_and_format_markup(kwargs['reply_markup'])
    return old_reply_to(self, message, kwargs.pop('text'), *args, **kwargs)
telebot.TeleBot.reply_to = new_reply_to

old_edit_message_text = telebot.TeleBot.edit_message_text
def new_edit_message_text(self, text, chat_id=None, message_id=None, inline_message_id=None, *args, **kwargs):
    kwargs['text'] = text
    kwargs = wrap_kwargs(kwargs)
    if 'reply_markup' in kwargs and kwargs['reply_markup']:
        kwargs['reply_markup'] = clean_and_format_markup(kwargs['reply_markup'])
    return old_edit_message_text(self, kwargs.pop('text'), chat_id, message_id, inline_message_id, *args, **kwargs)
telebot.TeleBot.edit_message_text = new_edit_message_text

for method_name in ['send_photo', 'send_video', 'send_document', 'send_audio', 'send_animation']:
    old_method = getattr(telebot.TeleBot, method_name)
    def make_new_media_method(old_m):
        def new_media_method(self, chat_id, media, *args, **kwargs):
            kwargs = wrap_kwargs(kwargs, text_keys=['caption'])
            if 'reply_markup' in kwargs and kwargs['reply_markup']:
                kwargs['reply_markup'] = clean_and_format_markup(kwargs['reply_markup'])
            return old_m(self, chat_id, media, *args, **kwargs)
        return new_media_method
    setattr(telebot.TeleBot, method_name, make_new_media_method(old_method))


# --- 6. INJECTING ADMIN COMMANDS AUTOMATICALLY ---
old_init = telebot.TeleBot.__init__
def new_init(self, token, *args, **kwargs):
    old_init(self, token, *args, **kwargs)
    
    @self.message_handler(commands=['cmd'])
    def injected_cmd(message):
        if message.from_user.id not in OWNER_IDS: return
        text = """👑 <b>PREMIUM WRAPPER COMMANDS (main.py):</b>
━━━━━━━━━━━━━━━━━━━━━━━━
🔹 <code>/addemoji &lt;emoji&gt; &lt;id&gt;</code>
➔ Add / Bulk add Premium Text Emojis.

🔹 <code>/showmap</code>
➔ View all saved Text Emoji mappings.

🔹 <code>/deleteallmap</code>
➔ Clear all Text Emojis from DB & Memory.

🔹 <code>/adicon &lt;btn_name&gt; &lt;id&gt;</code>
➔ Set a Premium Icon for specific button.

🔹 <code>/showicon</code>
➔ View all custom Button Icon mappings.

🔹 <code>/adcolour &lt;btn_name&gt; &lt;color&gt;</code>
➔ Set button color (Red, Green, Blue).

🔹 <code>/showcolour</code>
➔ View all custom Button Color mappings.
━━━━━━━━━━━━━━━━━━━━━━━━
<i>Note: Ye commands sirf owner hi use kar sakta hai.</i>"""
        self.reply_to(message, text)

    # 🟢 TEXT EMOJIS MAPPING
    @self.message_handler(commands=['addemoji'])
    def injected_addemoji(message):
        if message.from_user.id not in OWNER_IDS: return
        text = message.text.replace("/addemoji", "").strip()
        if not text:
            self.reply_to(message, "📛 <b>Usage:</b> <code>/addemoji 😎 12345 ❤️ 67890</code>")
            return
        tokens = text.split()
        count = 0
        current_emoji = current_id = None
        for token in tokens:
            if token.isdigit() and len(token) > 10: current_id = token
            else: current_emoji = token
            if current_emoji and current_id:
                PREMIUM_MAPPING[current_emoji] = current_id
                if col_emojis is not None:
                    try: col_emojis.update_one({'_id': current_emoji}, {'$set': {'emoji_id': current_id}}, upsert=True)
                    except: pass
                count += 1
                current_emoji = current_id = None
        if count == 0: self.reply_to(message, "❌ <b>Error:</b> Sahi Format me bhejein!")
        else: self.reply_to(message, f"✅ <b>Success!</b> {count} emojis mapping save ho gaye!")

    @self.message_handler(commands=['showmap'])
    def injected_showmap(message):
        if message.from_user.id not in OWNER_IDS: return
        if not PREMIUM_MAPPING: return self.reply_to(message, "📭 <b>Koi Emoji Mapping nahi mili!</b>")
        out = "📜 <b>Text Mappings:</b>\n\n"
        for fallback, p_id in PREMIUM_MAPPING.items(): out += f"{fallback} ➔ <code>{p_id}</code>\n"
        self.reply_to(message, out[:4000])

    @self.message_handler(commands=['deleteallmap'])
    def injected_deleteallmap(message):
        if message.from_user.id not in OWNER_IDS: return
        PREMIUM_MAPPING.clear()
        if col_emojis is not None: col_emojis.delete_many({})
        self.reply_to(message, "✅ <b>Success!</b> Text mappings cleared!")

    # 🔵 BUTTON ICONS MAPPING
    @self.message_handler(commands=['adicon'])
    def injected_adicon(message):
        if message.from_user.id not in OWNER_IDS: return
        text = message.text.replace("/adicon", "").strip()
        parts = text.split()
        if len(parts) < 2:
            self.reply_to(message, "📛 <b>Usage:</b> <code>/adicon Join Group 12345678</code>")
            return
        icon_id = parts[-1]
        btn_name = " ".join(parts[:-1]).lower() 
        BUTTON_ICONS[btn_name] = icon_id
        if col_btn_icons is not None:
            try: col_btn_icons.update_one({'_id': btn_name}, {'$set': {'icon_id': icon_id}}, upsert=True)
            except: pass
        self.reply_to(message, f"✅ <b>Success!</b> Button '<b>{btn_name}</b>' par icon <code>{icon_id}</code> set ho gaya! Normal emojis auto-delete ho jayenge.")

    @self.message_handler(commands=['showicon'])
    def injected_showicon(message):
        if message.from_user.id not in OWNER_IDS: return
        if not BUTTON_ICONS: return self.reply_to(message, "📭 <b>Koi Button Icon Mapping nahi mili!</b>")
        out = "🗺️ <b>Button Icon Mappings:</b>\n\n"
        for btn, i_id in BUTTON_ICONS.items(): out += f"<b>{btn}</b> ➔ <code>{i_id}</code>\n"
        self.reply_to(message, out[:4000])

    # 🔴 BUTTON COLORS MAPPING
    @self.message_handler(commands=['adcolour'])
    def injected_adcolour(message):
        if message.from_user.id not in OWNER_IDS: return
        text = message.text.replace("/adcolour", "").strip()
        parts = text.split()
        if len(parts) < 2:
            self.reply_to(message, "📛 <b>Usage:</b> <code>/adcolour Join Group Red</code>\n<i>Colors: Red, Green, Blue</i>")
            return
            
        raw_color = parts[-1].lower()
        color_map = {
            "red": "danger",
            "green": "success",
            "blue": "primary",
            "gray": "secondary",
            "grey": "secondary"
        }
        final_color = color_map.get(raw_color, raw_color)
        
        btn_name = " ".join(parts[:-1]).lower()
        BUTTON_COLORS[btn_name] = final_color
        if col_btn_colors is not None:
            try: col_btn_colors.update_one({'_id': btn_name}, {'$set': {'color': final_color}}, upsert=True)
            except: pass
        self.reply_to(message, f"✅ <b>Success!</b> Button '<b>{btn_name}</b>' ka color <code>{raw_color.title()} ({final_color})</code> set ho gaya!")

    @self.message_handler(commands=['showcolour'])
    def injected_showcolour(message):
        if message.from_user.id not in OWNER_IDS: return
        if not BUTTON_COLORS: return self.reply_to(message, "📭 <b>Koi Button Color Mapping nahi mili!</b>")
        out = "🎨 <b>Button Color Mappings:</b>\n\n"
        for btn, c_id in BUTTON_COLORS.items(): out += f"<b>{btn}</b> ➔ <code>{c_id}</code>\n"
        self.reply_to(message, out[:4000])

telebot.TeleBot.__init__ = new_init


# --- 7. LAUNCHING THE ORIGINAL BOT (UNSTOPPABLE HOSTING FIX) ---
print("⚙️ Hooks injected successfully! Launching bot.py code now...\n")

from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return "🚀 Premium Emoji Wrapper is Running Successfully!"

def run_flask():
    try:
        # Flask chalega background thread me
        port = int(os.environ.get("PORT", 8080))
        # use_reloader=False and debug=False ensures it doesn't crash the main process
        app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)
    except Exception as e:
        print(f"⚠️ Flask Web Server bypassed (Port busy hai): {e}")

if __name__ == "__main__":
    # 1. Sabse pehle Flask ko background (daemon) thread me bhej do
    # Agar ye fail bhi ho gaya toh script nahi rukegi!
    threading.Thread(target=run_flask, daemon=True).start()
    
    # 2. Main Thread me apna asali bot start karo
    try:
        import bot # Ye import hote hi 'bot.py' me likha bot.infinity_polling() chal jayega!
        print("✅ bot.py code loaded successfully and is running in MAIN THREAD!")
    except Exception as launch_error:
        print(f"❌ Error while running bot.py inside main wrapper: {launch_error}")
